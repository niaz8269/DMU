# Deploying dmu.cas.moe on 20i (subdomain of the cas.moe package)

The subdomain dmu.cas.moe already exists in the cas.moe package and points at `public_html/dmu`. Do not touch other folders.
First look inside `public_html/dmu`; if it already holds files, move them to `public_html/_dmu_backup` before you upload.

Layout (account root = /home/sites/.../):
- `dmu-app/`        : upload the contents of `app/` here (outside the web root).
- `public_html/dmu/`: upload the contents of `web/` here (index.php there points at ../../dmu-app).

1. StackCP > Databases > MySQL: create a database and user. Keep the password.
2. phpMyAdmin: import `01-template-schema.sql`, then `02-dmu-content.sql`. Never run `php artisan migrate`.
3. File Manager: upload `app/` to `dmu-app/` and `web/` to `public_html/dmu/`. Rename `dmu-app/.env.production.template` to `dmu-app/.env`.
4. Edit `dmu-app/.env` yourself: DB_DATABASE, DB_USERNAME, DB_PASSWORD, SMTP_HOST and SMTP_PASS (mailbox password). Keep APP_ENV=production.
5. Set PHP 8.3 for the subdomain (the .htaccess in `web/` already selects x-httpd-php83).
6. Admin password: SSH or the StackCP terminal, `cd dmu-app && /usr/bin/php83 artisan admin:set-password niaz@cas.moe` (hidden prompt).
7. CDN > Edge Caching > Purge Everything. Open https://dmu.cas.moe, check /sitemap.xml, log in at /login, send a test mail from the admin panel.
8. Search Console / Bing: add the new verification files to `public_html/dmu` and submit the sitemap.
