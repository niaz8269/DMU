<?php

use Illuminate\Foundation\Application;
use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

// The application lives outside the web root, in ../dmu-app.
if (file_exists($maintenance = __DIR__.'/../../dmu-app/storage/framework/maintenance.php')) {
    require $maintenance;
}

require __DIR__.'/../../dmu-app/vendor/autoload.php';

/** @var Application $app */
$app = require_once __DIR__.'/../../dmu-app/bootstrap/app.php';
$app->usePublicPath(__DIR__);

$app->handleRequest(Request::capture());
